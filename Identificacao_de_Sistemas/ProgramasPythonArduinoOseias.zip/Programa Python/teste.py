
import matplotlib.pyplot as plt

import numpy as np

x = np.random.rand(10)

plt.plot(x)
plt.show()

